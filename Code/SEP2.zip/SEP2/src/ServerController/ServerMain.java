package ServerController;

import ServerModel.SingleServer;

public class ServerMain
{
   public static void main(String[] args)
   {
      SingleServer server = SingleServer.getInstance();
   }
}

